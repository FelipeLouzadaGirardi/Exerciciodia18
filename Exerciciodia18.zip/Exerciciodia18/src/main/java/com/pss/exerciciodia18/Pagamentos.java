package com.pss.exerciciodia18;

public class Pagamentos {
    int valor;
    String operação;
    String codigo;

public int getValor() {
return valor;
};

public String getOperação(){
return operação;
}

public String getCodigo() {
    return codigo;
}


public void setValor(int nome) {
    this.valor = valor;
}

public void setOperação(String operação) {
    this.operação = operação;
}
public void setCodigo(String codigo) {
    this.codigo = codigo;
}

}