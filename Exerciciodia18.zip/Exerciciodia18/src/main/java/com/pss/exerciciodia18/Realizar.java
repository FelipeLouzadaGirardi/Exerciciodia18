
package com.pss.exerciciodia18;


public class Realizar {
    private int realizar;

    public int getRealizar() {
        return realizar;
    }

    public void setRealizar(int realizar) {
        this.realizar = realizar;
    }
    
}
