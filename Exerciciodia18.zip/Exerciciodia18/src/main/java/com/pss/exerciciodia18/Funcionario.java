package com.pss.exerciciodia18;


public class Funcionario {
private String cargo; 

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
   
}