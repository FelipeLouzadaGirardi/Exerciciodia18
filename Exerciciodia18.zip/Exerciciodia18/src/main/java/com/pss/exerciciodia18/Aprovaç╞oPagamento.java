package com.pss.exerciciodia18;

public class AprovaçãoPagamento {
    int valor;
    String codigo;
    

public int getValor(){
    return valor;
}

    public String getCodigo() {
        return codigo;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
}



