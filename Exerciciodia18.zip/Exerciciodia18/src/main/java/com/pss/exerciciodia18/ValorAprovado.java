
package com.pss.exerciciodia18;


public class ValorAprovado{
    
    public static void cargo (int valor, Realizar realizar) {

        if (valor <= 500) {
            System.out.println("Gerente Imediato ao Funcionário tem permissão para aprovar o pagamento");
            realizar.setRealizar(1);
        } else if (valor > 500 && valor <= 1500) {
            System.out.println("Gerente Geral e superiores tem permissão para aprovar o pagamento");
            realizar.setRealizar(2);
        } else if (valor > 1500 && valor <= 5000) {
            System.out.println("Diretor Financeiro e superiores tem permissão para aprovar o pagamento");
            realizar.setRealizar(3);
        } else if (valor > 5000 && valor <= 15000) {
            System.out.println("Diretor Geral e superiores tem permissão para aprovar o pagamento");
            realizar.setRealizar(4);
        }
    
    
}
}