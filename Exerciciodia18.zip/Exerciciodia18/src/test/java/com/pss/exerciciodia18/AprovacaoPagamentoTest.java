package com.pss.exerciciodia18;



import com.pss.exerciciodia18.ValorAprovado;
import static java.time.Clock.system;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class AprovacaoPagamentoTest {

    public AprovacaoPagamentoTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    @Test
    public void Teste01() {
        int y;
        y = 1;
        
        Realizar realizar = new Realizar();
                
        ValorAprovado.cargo(500,realizar);
        assertEquals (y,realizar.getRealizar());   
    } 
   @Test
    public void Teste02() {
        int y;
        y = 2;
        
        Realizar realizar = new Realizar();
                
        ValorAprovado.cargo(1500,realizar);
        assertEquals (y,realizar.getRealizar());   
    } 
    @Test
    public void Teste03() {
        int y;
        y = 3;
        
        Realizar realizar = new Realizar();
                
        ValorAprovado.cargo(5000,realizar);
        assertEquals (y,realizar.getRealizar());   
    } 
    
    @Test
    public void Teste04() {
        int y;
        y = 4;
        
        Realizar realizar = new Realizar();
                
        ValorAprovado.cargo(15000,realizar);
        assertEquals (y,realizar.getRealizar());   
    } 
    
}


